/*=auto=========================================================================

(c) Copyright 2001 Massachusetts Institute of Technology

Permission is hereby granted, without payment, to copy, modify, display 
and distribute this software and its documentation, if any, for any purpose, 
provided that the above copyright notice and the following three paragraphs 
appear on all copies of this software.  Use of this software constitutes 
acceptance of these terms and conditions.

IN NO EVENT SHALL MIT BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, 
INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OF THIS SOFTWARE 
AND ITS DOCUMENTATION, EVEN IF MIT HAS BEEN ADVISED OF THE POSSIBILITY OF 
SUCH DAMAGE.

MIT SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTIES INCLUDING, 
BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR 
A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.

THE SOFTWARE IS PROVIDED "AS IS."  MIT HAS NO OBLIGATION TO PROVIDE 
MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.

=========================================================================auto=*/
#include <stdio.h>
#include "vtkVersion.h"
#if (VTK_MAJOR_VERSION == 3 && VTK_MINOR_VERSION == 2)
#include "vtkCommand.h"
#endif
#include "vtkMrmlVolume.h"
#include "vtkObjectFactory.h"
#include "vtkImageReader.h"
#include "vtkImageWriter.h"
#include "vtkImageCanvasSource2D.h"
#include "vtkImageCopy.h"
#include <time.h>

#include "vtkImageDICOMReader.h"

//------------------------------------------------------------------------------
vtkMrmlVolume* vtkMrmlVolume::New()
{
  // First try to create the object from the vtkObjectFactory
  vtkObject* ret = vtkObjectFactory::CreateInstance("vtkMrmlVolume");
  if(ret)
  {
    return (vtkMrmlVolume*)ret;
  }
  // If the factory was unable to create the object, then create it here.
  return new vtkMrmlVolume;
}

//----------------------------------------------------------------------------
vtkMrmlVolume::vtkMrmlVolume()
{
  // Allocate VTK objects
  this->Accumulate = vtkImageAccumulateDiscrete::New();
  this->Bimodal = vtkImageBimodalAnalysis::New();
  this->Resize = vtkImageResize::New();
  this->HistPlot = vtkImagePlot::New();
  this->IndirectLUT = vtkIndirectLookupTable::New();

  // Objects thate should be set by the user, but can be self-created
  this->MrmlNode = NULL;
  this->ImageData = NULL;
  this->LabelIndirectLUT = NULL;

  this->UseLabelIndirectLUT = 0;
 
  // W/L Slider range 
  this->RangeAuto = 1;
  this->RangeLow = 0;
  this->RangeHigh = 0;

  this->HistogramColor[0] = 1;
  this->HistogramColor[1] = 0;
  this->HistogramColor[2] = 0;
  
  this->ProcessObject = NULL;

  // NOTE: ImageData has a reference count of 2 because it is the ImageData
  // of this and the Input of this->Accumulate.
  // If we call SetImageData [something else] then the reference count drops
  // to 1.  Then when we call this->Update, then this->Accumulate gets a
  // new input and the reference count of the original ImageData drops to 0
  // and the object is deleted from memory.

}

//----------------------------------------------------------------------------
vtkMrmlVolume::~vtkMrmlVolume()
{
  // Delete if self-created or if no one else is using it
  if (this->ImageData != NULL) 
  {
    this->ImageData->UnRegister(this);
  }
  if (this->MrmlNode != NULL)
  {
    this->MrmlNode->UnRegister(this);
  }
  if (this->LabelIndirectLUT != NULL)
  {
    this->LabelIndirectLUT->UnRegister(this);
  }

  // Delete objects we allocated
  this->Accumulate->Delete();
  this->Bimodal->Delete();
  this->Resize->Delete();
  this->HistPlot->Delete();
  this->IndirectLUT->Delete();
}

//----------------------------------------------------------------------------
void vtkMrmlVolume::PrintSelf(ostream& os, vtkIndent indent)
{
  vtkProcessObject::PrintSelf(os, indent);

  os << indent << *this->HistPlot   << endl;
  os << indent << "UseLabelIndirectLUT: " << this->UseLabelIndirectLUT << endl;
  os << indent << "Range Low: " << this->RangeLow << endl;
  os << indent << "Range High: " << this->RangeHigh << endl;
  os << indent << "Range Auto: " << this->RangeAuto << endl;

  // vtkSetObjectMacro
  os << indent << "MrmlNode: " << this->MrmlNode << "\n";
  if (this->MrmlNode)
  {
    this->MrmlNode->PrintSelf(os,indent.GetNextIndent());
  }

  os << indent << "ImageData: " << this->ImageData << "\n";
  if (this->ImageData)
  {
    this->ImageData->PrintSelf(os,indent.GetNextIndent());
  }

  os << indent << "LabelIndirectLUT: " << this->LabelIndirectLUT << "\n";
  if (this->LabelIndirectLUT)
  {
    this->LabelIndirectLUT->PrintSelf(os,indent.GetNextIndent());
  }
}

//----------------------------------------------------------------------------
void vtkMrmlVolume::CopyNode(vtkMrmlVolume *volume)
{
  this->GetMrmlNode()->Copy(volume->GetMrmlNode());
}

//----------------------------------------------------------------------------
// Determine the modified time of this object
unsigned long int vtkMrmlVolume::GetMTime()
{
  unsigned long result, t;

  result = vtkObject::GetMTime();
 
  // ImageData
  if (this->ImageData)
  {
    t = this->ImageData->GetMTime(); 
    result = (t > result) ? t : result;
  }
 
  // MrmlNode
  if (this->MrmlNode)
  {
    t = this->MrmlNode->GetMTime(); 
    result = (t > result) ? t : result;
  }
 
  // LabelIndirectLUT 
  if (this->UseLabelIndirectLUT && this->LabelIndirectLUT)
  {
    t = this->LabelIndirectLUT->GetMTime(); 
    result = (t > result) ? t : result;
  }
  return result;
}

//----------------------------------------------------------------------------
void vtkMrmlVolume::CheckImageData()
{
  // If the user has not set the ImageData, then create it.
  // The key is to perform: New(), Register(), Delete().
  // Then we can call UnRegister() in the destructor, and it will delete
  // the object if no one else is using it.  We don't have to distinguish
  // between whether we created the object, or someone else did!

  if (this->ImageData == NULL)
  {
    // Give it a size that matches with the MrmlNode (but 2D)
    int dim[2];
    short s=0;
    vtkMrmlVolumeNode *node = this->MrmlNode;
    node->GetDimensions(dim);

    vtkImageCanvasSource2D *canvas = vtkImageCanvasSource2D::New();
    canvas->SetScalarType(node->GetScalarType());
    canvas->SetNumberOfScalarComponents(node->GetNumScalars());
    canvas->SetExtent(0, dim[0]-1, 0, dim[1]-1, 0, 0);
    canvas->SetSpacing(node->GetSpacing());
    canvas->SetDrawColor(s);
    canvas->FillBox(0, dim[0]-1, 0, dim[0]-1);

    vtkImageCopy *copy = vtkImageCopy::New();
    copy->SetInput(canvas->GetOutput());
    copy->Update();
    this->SetImageData(copy->GetOutput());
    copy->SetOutput(NULL);
    copy->Delete();
	  canvas->Delete();
  }
}

//----------------------------------------------------------------------------
void vtkMrmlVolume::CheckMrmlNode()
{
  // If the user has not set the ImageData, then create it.
  // The key is to perform: New(), Register(), Delete().
  // Then we can call UnRegister() in the destructor, and it will delete
  // the object if no one else is using it.  We don't have to distinguish
  // between whether we created the object, or someone else did!

  if (this->MrmlNode == NULL)
  {
    this->MrmlNode = vtkMrmlVolumeNode::New();
    this->MrmlNode->Register(this);
    this->MrmlNode->Delete();
  }
}

//----------------------------------------------------------------------------
void vtkMrmlVolume::CheckLabelIndirectLUT()
{
  if (this->LabelIndirectLUT == NULL)
  {
    this->LabelIndirectLUT = vtkIndirectLookupTable::New();
    this->LabelIndirectLUT->Register(this);
    this->LabelIndirectLUT->Delete();
  }
}

//----------------------------------------------------------------------------
void vtkMrmlVolume::Update()
{
  int ext[6];
  
  // We really should have an Update time that we compare with the
  // MTime, but since the other objects inside this class do this, 
  // its alright.

  // Create objects that the user hasn't already set
  this->CheckMrmlNode();
  this->CheckImageData();
  this->CheckLabelIndirectLUT();

  // Connect pipeline
  this->Accumulate->SetInput(this->ImageData);
  this->Accumulate->Update();
  this->Bimodal->SetInput(this->Accumulate->GetOutput());
  this->Bimodal->Update();
  this->Bimodal->GetClipExtent(ext);
  this->Resize->SetInputClipExtent(ext);
  this->Resize->SetInput(this->Accumulate->GetOutput());
  this->Resize->Update();
  this->HistPlot->SetInput(this->Resize->GetOutput());


  // Bound W/L range and apply auto if requested
  this->UpdateWindowLevelThreshold();
}

//----------------------------------------------------------------------------
vtkImageData* vtkMrmlVolume::GetOutput()
{
  this->Update();
  return this->ImageData;
}

//----------------------------------------------------------------------------
void vtkMrmlVolume::UpdateWindowLevelThreshold()
{
  int window, level, upper, lower;

  // Compute the range using the accumulator and bimodal analysis.
  // The common case is auto W/L, so we want this to be the fastest.
  //
  this->Bimodal->Update();

  // Auto Range
  if (this->RangeAuto) 
  {
    this->RangeLow  = this->Bimodal->GetMin();
    this->RangeHigh = this->Bimodal->GetMax();
  }
  
  // Auto W/L
  if (this->MrmlNode->GetAutoWindowLevel())
  {
    this->MrmlNode->SetLevel(this->Bimodal->GetLevel());
    this->MrmlNode->SetWindow(this->Bimodal->GetWindow());
  }

  // Auto Threshold
  if (this->MrmlNode->GetAutoThreshold())
  {
    this->MrmlNode->SetLowerThreshold(this->Bimodal->GetThreshold());
    this->MrmlNode->SetUpperThreshold(this->Bimodal->GetMax());
  }

  // Force Window/Level/Thresh to be within the Range
  level  = this->MrmlNode->GetLevel();
  window = this->MrmlNode->GetWindow();
  upper  = this->MrmlNode->GetUpperThreshold();
  lower  = this->MrmlNode->GetLowerThreshold();

  // Clip Level
  if (level < this->RangeLow) 
  {
    level = this->RangeLow;
    this->MrmlNode->SetLevel(level);
  } 
  else if (level > this->RangeHigh) 
  {
    level = this->RangeHigh;
    this->MrmlNode->SetLevel(level);
  }

  // Clip Window
  if (window < 0) 
  {
    window = 0;
    this->MrmlNode->SetWindow(window);
  }
  if (window > (this->RangeHigh - this->RangeLow + 1)) 
  {
    window = this->RangeHigh - this->RangeLow + 1;
    this->MrmlNode->SetWindow(window);
  }

  // Clip UpperThreshold
  if (upper < this->RangeLow) 
  {
    upper = this->RangeLow;
    this->MrmlNode->SetUpperThreshold(upper);
  } 
  else if (upper > this->RangeHigh) 
  {
    upper = this->RangeHigh;
    this->MrmlNode->SetUpperThreshold(upper);
  }

  // Clip LowerThreshold 
  if (lower < this->RangeLow) 
  {
    lower = this->RangeLow;
    this->MrmlNode->SetLowerThreshold(lower);
  } 
  else if (lower > this->RangeHigh) 
  {
    lower = this->RangeHigh;
    this->MrmlNode->SetLowerThreshold(lower);
  }

  // Do not apply W/L to the LabelIndirectLUT
  if (this->UseLabelIndirectLUT == 0)
  {
    this->IndirectLUT->SetLevel(level);
    this->IndirectLUT->SetWindow(window);
    this->IndirectLUT->SetLowerThreshold(lower);
    this->IndirectLUT->SetUpperThreshold(upper);
    this->IndirectLUT->SetApplyThreshold(this->MrmlNode->GetApplyThreshold());
    this->IndirectLUT->Build();
  }
}

//----------------------------------------------------------------------------
vtkImageData* vtkMrmlVolume::GetHistogramPlot()
{
  int ext[6];
  int signalRange[2];

  // Update pipeline for the plot
  this->Update();
  this->Bimodal->GetClipExtent(ext);
  this->Bimodal->GetSignalRange(signalRange);
  this->Resize->SetInputClipExtent(ext);
  this->HistPlot->SetDataRange(0, signalRange[1]);
  this->HistPlot->SetDataDomain(
    this->Bimodal->GetMin(), this->Bimodal->GetMax());
  this->HistPlot->SetLookupTable(this->GetIndirectLUT());
  this->HistPlot->SetColor(this->HistogramColor);
  this->HistPlot->Update();
  
  return this->HistPlot->GetOutput();
}

//----------------------------------------------------------------------------
void vtkMrmlVolumeProgress(void *arg)
{
  vtkMrmlVolume *self = (vtkMrmlVolume *)(arg);
  vtkProcessObject *obj = self->GetProcessObject();
  if (obj)
  {
    self->UpdateProgress(obj->GetProgress());
  }
}

//----------------------------------------------------------------------------
void vtkMrmlVolume::Read()
{
  int ext[6], *range, *dim;
  vtkMrmlVolumeNode *node;

  // Create objects that don't already exist
  this->CheckMrmlNode();
  node = this->MrmlNode;

  // Start progress reporting
#if (VTK_MAJOR_VERSION == 3 && VTK_MINOR_VERSION == 2)
    this->InvokeEvent(vtkCommand::StartEvent,NULL);
#else
  if (this->StartMethod)
  {
    (*this->StartMethod)(this->StartMethodArg);
  }
#endif  
  range = node->GetImageRange();
  dim = node->GetDimensions();
  ext[0] = 0;
  ext[1] = dim[0] - 1;
  ext[2] = 0;
  ext[3] = dim[1] - 1;
  ext[4] = range[0];
  ext[5] = range[1];

  //
  // Modified by Attila Tanacs 8/28/2000
  //

  vtkImageSource *reader;

  // try as DICOM

  if(node->GetNumberOfDICOMFiles() > 0)
    { // DICOM
      vtkImageDICOMReader *dcmreader = vtkImageDICOMReader::New();
      dcmreader->SetNumberOfScalarComponents(node->GetNumScalars());
      dcmreader->SetDataScalarType(node->GetScalarType());
      dcmreader->SetDataByteOrder(node->GetLittleEndian());
      dcmreader->SetDataSpacing(node->GetSpacing());
      dcmreader->SetFilePattern(node->GetFilePattern());
      dcmreader->SetFilePrefix(node->GetFullPrefix());
      dcmreader->SetDataExtent(ext);

      dcmreader->SetDICOMFileNames(node->GetNumberOfDICOMFiles(), node->GetDICOMFileNamesPointer());

      //if(dcmreader->GetDICOMHeaderSize( = ran -----());

rogress reportim);

    vtkImageCanvasSource2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
c
ce2D ));ip[1] = dim[0] -ot
f>MrmlNodeiSource2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
c
ce2D ));ip[1] = dim[0] -ot
f>MrmlNodnvasSource2D ));
ce22D eSou);
ce2D ));
ce2D ));
cBImageResig--- i;nZ2O>SetDICOileNames(node->GetrOfDICOMFiles(), nodeietDICOMFileNamesPointer());

      //if(dcmreader->GetDICOMHeaderSi( = ran -----());

rogress reportim);

    vtkImageCanvai( = ran -----() ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ci( = ran -----())2D ));
ce2D ));
ce2D ));
ce2D ));
iD ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2iD ));
ce2D ));
c ));
ce2D ));
ce2D ));
ce2D ));
c
cei( = ran -----()kMrmlVolume *seeeee);
ce2D ));
ce2D ));
ce2D ));
ce2D i
ce2D ));
c}ing());
   etFileP->SetF (*this-Labelbackrange[1];----------------
ce2D ));
( = ran --- (*this-calarC(lNode;

  // Start pr, ogress )Indirect
s->GetNad------( = ran l->GetThreshold(DetfIteice2D dtSpa we a( = rarange[1];it.  We don'tce2D ));
ceateWindowLeve( = ran --- whether we creage[1];----------------ng else];
ce2D ));
cBImageRes------
  vtkImageSource *reader;

  // try as DICOM

  if(node->GetNumberOfDICOMFiles() > 0)
    { // DICOM
      v---geDICOMReader *dcmreader = vtkI---ICOMReader::New();
     ---ICOMRea = vtkI---ICOMReomponents reateIns return thisde->Ge
}

//----------hod)(this->StartMethodArg);
  }
#endif  
  range = node->GetImageRange();
  dim = node->GetDimensions(turn torting
#if (VTK_MAJ;
  ext[3] = dithis->Resize->GetOutput());


  // Bound W/L range );
    copy->SetInput(can/2000
  //

  vtkImageSource *reader;

  // try as DICOM

  if(node->GetNumberOfDICOMFiles() > 0)
    { // DICOM
      vtkImageDICOMReader *dcmreader = vtkImageDICOMReader::New();
      dcmreader->SetNumberOfScalarComponents(node->can/20as unable to c *w to c =0as unable to cOMFiles(), w to cce2D ));
ce2D ));
ce2D ));
ce2D ));
ce2D ));w to cce2D ));
c ));
ce2D ));
ce2D ));
ce2D ));
w to cce2D --------------------------->SetF (*this-Labelbackranw to cce2D  (*this-calarC(lNode;

  // Start pr, ogress )Indirectthis->Mrp(*this-Labelback funDescrineedtkMrh     // Orce2w to c reage[1];----------------w to cect
s->GeNumber-----w to cceturn to
  }
  to cce2D ------r we crea  to cce);
cBImageRes------
  vtkImageSource *reader;

  // try as DICOM

  if(node->GetNumberOfDICOMFiles() > 0)
    { // DICOM
      v---geDICOMReader *dcmreader = vtkI---ICOMReader::New();
     ---ICOMRea = vtkI---ICOMReomponents reateInshod)(this->StartMethodArg);
 